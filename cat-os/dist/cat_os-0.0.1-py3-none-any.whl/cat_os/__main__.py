import argparse

def main():
    parser = argparse.ArgumentParser(
        prog="cat-os",
        description="Cat-OS Command Line Tool"
    )

    parser.add_argument(
        "--version",
        action="store_true",
        help="Show Cat-OS version"
    )

    args = parser.parse_args()

    if args.version:
        print("Cat-OS 1.0")
        return

    parser.add_argument(
        "--cmd",
        action="store_true",
        help='CMD\nmeow()\nnerd()\nstory("luna")\nplayA("cat")\nplayB("BFF")\nplay()'
    )

    print("Welcome to cat-os!")

if __name__ == "__main__":
    main()